# README of repository GetCommitMessagesTestRepository

This is a test repository for functional tests.
